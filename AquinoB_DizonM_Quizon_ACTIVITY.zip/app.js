// Aquino, Bea Nichole T. - Dizon, Maycee G. - Quizon, Megan Rae L.
// CS - 401     6ASI    Activity
// September 30, 2021

const express = require('express');
const app = express();
const port = 3000;
const admin = require('firebase-admin');


var serviceAccount = require("D:/programming/nodejsCRUD/nodejscrud-f83f9-firebase-adminsdk-yxfbz-3b2178925a.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://nodejscrud-f83f9-default-rtdb.asia-southeast1.firebasedatabase.app"
});


app.use(express.json());
app.use(express.static('public'));

const database = admin.database();
const studentRef = database.ref('/student/');


app.get('/',(req,res) => {
    res.send('index');
});

app.post('/save',(req, res) => {
    database.ref('/student/' + req.body.student_id).set({

        first_name: req.body.first_name,
        last_name:req.body.last_name,
        section: req.body.section
    });
});

app.put('/update', (req, res) => {
    const newData = {
        section: req.body.section,
        first_name: req.body.first_name,
        last_name: req.body.last_name
    };
    studentRef.child(req.body.student_id).update(newData);
});

app.delete('/remove', (req, res) => {
    studentRef.child(req.body.student_id).remove();
});

studentRef.on('child_added', snapshot => {
    console.log('A new student has enrolled.');
    console.log(snapshot.val());
});

studentRef.on('child_changed', snapshot => {
    console.log('A student has modified their information.');
});

studentRef.on('child_removed', snapshot => {
    console.log('A student has deleted their account.');
});



app.listen(port, () => {
    console.log(`I am listening to port ${port}`);
});
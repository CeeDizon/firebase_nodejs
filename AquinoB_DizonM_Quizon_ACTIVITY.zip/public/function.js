// Aquino, Bea Nichole T. - Dizon, Maycee G. - Quizon, Megan Rae L.
// CS - 401     6ASI    Activity
// September 30, 2021

const studentId = document.getElementById('studentId');
const lastName = document.getElementById('lastName');
const firstName = document.getElementById('firstName');
const section = document.getElementById('section');
const createButton = document.getElementById('createButton');
const updateButton = document.getElementById('updateButton');
const deleteButton = document.getElementById('deleteButton');



createButton.addEventListener('click', e => {
    console.log('test');
    e.preventDefault();
    axios({
        method: 'post',
        url: '/save',
        data: {
            student_id: studentId.value,
            last_name: lastName.value,
            first_name: firstName.value,
            section: section.value
        }
    });
});

updateButton.addEventListener('click', e => {
    console.log('test');
    e.preventDefault();
    axios({
        method: 'put',
        url: '/update',
        data: {
            student_id: studentId.value,
            first_name: firstName.value,
            last_name: lastName.value,
            section: section.value
        }
    });
});


deleteButton.addEventListener('click', e => {
    console.log('test');
    e.preventDefault();
    axios({
        method: 'delete',
        url: '/remove',
        data: {
            student_id: studentId.value
        }
    });
});